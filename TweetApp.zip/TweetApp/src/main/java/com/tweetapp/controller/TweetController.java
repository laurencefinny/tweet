package com.tweetapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.request.TweetRequest;
import com.tweetapp.response.TweetResponse;
import com.tweetapp.service.TweetsService;

@RestController
public class TweetController {

	@Autowired
	TweetsService tweetsService;

	@GetMapping(value = "/api/v1.0/tweets/all")
	public TweetResponse getAllTweets() {
		return tweetsService.getAllTweets();
	}

	@GetMapping(value = "/api/v1.0/tweets/{username}" )
	public TweetResponse getAllTweetsUser(@PathVariable("username") String userName) {
		return tweetsService.getAllTweetsByUserName(userName);
		
	}
	
	@PostMapping(value = "/api/v1.0/tweets/{username}/add" )
	public TweetResponse addTweet(@RequestBody TweetRequest request , @PathVariable("username") String userName ) {
		return tweetsService.addTweet(request, userName);	
	}
	
	@RequestMapping(path = "/api/v1.0/tweets/{username}/delete/{id}" , method = RequestMethod.DELETE)
	public TweetResponse deleteTweet(@PathVariable("username") String userName, @PathVariable("id") Long tweetId) {
		return tweetsService.deleteTweet(userName,tweetId);
		
	}
	
	@PostMapping(value = "/api/v1.0/tweets/reply" )
	public TweetResponse replyToTweet(@RequestBody TweetRequest request ) {
		return tweetsService.replyToTweet(request);	
	}
	
	@RequestMapping(value="/api/v1.0/tweets/like",method = RequestMethod.POST)
	public TweetResponse likeATweet(@RequestBody  TweetRequest request ) {
		return tweetsService.likeATweet(request);
	}
	
	@RequestMapping(value="/api/v1.0/tweets/update",method = RequestMethod.POST)
	public TweetResponse updateTweet(@RequestBody  TweetRequest request ) {
		return tweetsService.updateTweet(request);
	}
	
	
}
